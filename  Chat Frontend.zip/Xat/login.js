function checkUser() {
    let http = new XMLHttpRequest();

    let mail = document.getElementById("email").value;
    let pass = document.getElementById("pass").value;

    http.open("GET", "http://localhost:3000/Xat/Login?mail=" + mail + "&pass=" + pass, true);
    http.send();

    http.onreadystatechange = function () {

        if (this.readyState == 4 && this.status == 200) {

            console.log(http.responseText);

            if (http.responseText == "false") {
                document.getElementById("resultado").style.color = "red";
                document.getElementById("resultado").innerHTML = "Email o contraseña incorrecta.";
                
                
            }
            else {
                sessionStorage.setItem("mail", mail);
                sessionStorage.setItem("session", http.responseText);

                window.location.href = "xat.html";
            }

        }
    }
}

function goToRegister(){
    window.location.href = "register.html";
}