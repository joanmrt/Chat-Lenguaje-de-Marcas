function goToLogin() {
    window.location.href = "login.html";
}

function register() {
    let http = new XMLHttpRequest();

    let mail = document.getElementById("email").value;
    let pass = document.getElementById("pass").value;
    let user = document.getElementById("user").value;
    let codeCountry = document.getElementById("countries").value;

    http.open("POST", "http://localhost:3000/Xat/Register?mail=" + mail + "&pass=" + pass + "&user=" + user + "&codeCountry=" + codeCountry, true);
    http.send();

    http.onreadystatechange = function () {

        if (this.readyState == 4 && this.status == 200) {

            console.log(http.responseText);
            let result = http.responseText;

            if (result == "true"){
                document.getElementById("resultado").innerHTML = "¡Registro insertado correctamente!";

            }
            if (result == "false"){
                document.getElementById("resultado").innerHTML = "El registro no se ha insertado. Inténtelo de nuevo.";
            }
            

        }
    }
}

function getCountries(){

    let http = new XMLHttpRequest();

    http.open("GET", "http://localhost:3000/Xat/Register", true);
    http.send();

    http.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {


            var jsonString = http.responseText;
            console.log(jsonString);
            var optionsArray = JSON.parse(jsonString);
            var select = document.getElementById("countries");

            //Iterar por toda la array añadir option

            for (let i = 0; i < optionsArray.length; i++) {
                var option = optionsArray[i];

                var newOption = document.createElement("option");
                newOption.value = option.code;
                newOption.text = option.name;

                select.appendChild(newOption);
            }
        }
    }
}