// Array para comprobar las conversaciones activas
let conversaciones = [];

function send() {
    let http = new XMLHttpRequest();

    let mail = sessionStorage.getItem("mail");
    let session = sessionStorage.getItem("session");
    let sms = document.getElementById("messageInput").value;
    let receptor = document.getElementById("friends").value;

    if (conversaciones.includes(receptor)){
        let messagep = document.createElement("p");
            messagep.textContent = "Tú - " + sms;
                
            document.getElementById(receptor).append(messagep);
    }
    else{
        // Crear chat invisible
        conversaciones.push(receptor);
        let newChat = document.createElement("div");
        newChat.id = receptor;
        document.getElementById("messageBox").append(newChat);

        // Añadir el texto
        let messagep = document.createElement("p");
        messagep.textContent = "Tú - " + sms;

        document.getElementById(receptor).append(messagep);
    }

    http.open("POST", "http://localhost:3000/Xat/Xat?mail=" + mail + "&session=" + session + "&sms=" + sms + "&receptor=" + receptor, true);
    http.send();

    http.onreadystatechange = function () {

        if (this.readyState == 4 && this.status == 200) {
            console.log("enviado");
            document.getElementById("messageInput").value = "";
        }
    }
}

function getMessages() {
    let http = new XMLHttpRequest();

    let mail = sessionStorage.getItem("mail");
    let session = sessionStorage.getItem("session");

    


    http.open("GET", "http://localhost:3000/Xat/Xat?mail=" + mail + "&session=" + session, true);
    http.send();

    http.onreadystatechange = function () {

        if (this.readyState == 4 && this.status == 200) {

            console.log(http.responseText);

            var messageArray = http.responseText;
            var messageJson = JSON.parse(messageArray);
            console.log(messageJson);
            console.log(conversaciones);

            // Comprobar de quien es el mensaje
            if (conversaciones.includes(messageJson.emisor)){
                
                let messagep = document.createElement("p");
                messagep.textContent = messageJson.emisor + " - " + messageJson.text;
                
                document.getElementById(messageJson.emisor).append(messagep);

            }

            else{
                // Crear chat invisible
                conversaciones.push(messageJson.emisor);
                let newChat = document.createElement("div");
                newChat.id = messageJson.emisor;
                newChat.style.display = "none";
                document.getElementById("messageBox").append(newChat);

                // Añadir el texto
                let messagep = document.createElement("p");
                messagep.textContent = messageJson.emisor + " - " + messageJson.text;

                document.getElementById(messageJson.emisor).append(messagep);

                // Añadir aviso del mensaje pendiente
                let aviso = document.createElement("p");
                aviso.textContent = "Mensaje recibido de " + messageJson.emisor;
                document.getElementById("activeMessages").append(aviso);

            }

            getMessages();
        }
    }
}

function showConver(){
    try {
        let friend = document.getElementById("friends").value;

        document.getElementById(friend).style.display = "block";
    } catch (error) {
        console.log("conversacion no existente");
    }
    
}

function hideConver(){
    try {
        let friend = document.getElementById("friends").value;

        document.getElementById(friend).style.display = "none"

    } catch (error) {
        console.log("conversacion no existente");

    }
    

}

function getFriends() {
    let http = new XMLHttpRequest();

    let mail = sessionStorage.getItem("mail");
    let session = sessionStorage.getItem("session");



    http.open("GET", "http://localhost:3000/Xat/Friend?mail=" + mail + "&session=" + session, true);
    http.send();

    http.onreadystatechange = function () {

        if (this.readyState == 4 && this.status == 200) {

            console.log(http.responseText);

            var friendArray = http.responseText;
            var friendJson = JSON.parse(friendArray);
            console.log(friendJson);
            var select = document.getElementById("friends")
            select.innerHTML = "";

            for (let i = 0; i < friendJson.length; i++) {

                var newOption = document.createElement("option");
                newOption.value = friendJson[i];
                newOption.text = friendJson[i];

                select.appendChild(newOption);
            }

        }
    }
}

function addFriend() {
    let http = new XMLHttpRequest();

    let mail = sessionStorage.getItem("mail");
    let session = sessionStorage.getItem("session");
    let friend = document.getElementById("addFriend").value;


    http.open("POST", "http://localhost:3000/Xat/Friend?mail=" + mail + "&session=" + session + "&friend=" + friend, true);
    http.send();

    http.onreadystatechange = function () {

        if (this.readyState == 4 && this.status == 200) {

            console.log(http.responseText);
            let result = http.responseText;

            if (result == "0") {
                document.getElementById("respuestaFriend").innerHTML = "El servidor no responde.";
            }

            if (result == "1") {
                document.getElementById("respuestaFriend").innerHTML = "¡El amigo ha sido añadido correctamente!";
            }

            if (result == "2") {
                document.getElementById("respuestaFriend").innerHTML = "No se encuentra ningún usuario con ese correo.";
            }

            if (result == "3") {
                document.getElementById("respuestaFriend").innerHTML = "Sessión expirada. Por favor vuelve a inicar sesión.";
            }

            document.getElementById("addFriend").value = "";
            getFriends();
        }
    }
}

function logout() {
    sessionStorage.removeItem("mail");
    sessionStorage.removeItem("session");

    window.location.href = "login.html";
}